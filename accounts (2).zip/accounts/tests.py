from django.test import TestCase
from django.contrib.auth import get_user_model
from .models import Profile, FavoriteSalon
from appointments.models import Salon  # appointments uygulamasındaki model

User = get_user_model()

class CustomUserTest(TestCase):
    def test_user_creation(self):
        user = User.objects.create_user(username='testuser', password='testpass')
        self.assertEqual(user.username, 'testuser')
        self.assertTrue(user.check_password('testpass'))


class ProfileTest(TestCase):
    def test_profile_created_on_user_creation(self):
        user = User.objects.create_user(username='profileuser', password='testpass')
        self.assertTrue(hasattr(user, 'profile'))  # signals.py sayesinde otomatik oluşmalı


class FavoriteSalonTest(TestCase):
    def test_favorite_salon_creation(self):
        user = User.objects.create_user(username='favuser', password='testpass')
        salon = Salon.objects.create(name='Test Salon', address='Test Adres')  # Örnek salon
        fav = FavoriteSalon.objects.create(user=user, salon=salon)
        self.assertEqual(fav.user.username, 'favuser')
        self.assertEqual(fav.salon.name, 'Test Salon')
