# accounts/urls.py
from django.urls import path
from .views import CustomLoginView, CustomLogoutView, register_view, profile_view, toggle_favorite
from . import views
from .views import profile_view
from django.contrib.auth.views import PasswordChangeView

app_name = 'accounts'

urlpatterns = [
   path('konum-al/', views.konum_al, name='konum_al'),

   

    path("sifre-degis/", PasswordChangeView.as_view(template_name="accounts/password_change.html"), name="password_change"),
    path('profilim/', profile_view, name='profile'),
    path('profile/', profile_view, name='profile'),
    path('login/',    CustomLoginView.as_view(),  name='login'),
    path('logout/',   CustomLogoutView.as_view(), name='logout'),
    path('register/', register_view,              name='register'),
    
    path('favori/<int:salon_id>/', toggle_favorite, name='toggle_favorite'),
    path('tema-degistir/', views.toggle_theme, name='toggle_theme'),

]

