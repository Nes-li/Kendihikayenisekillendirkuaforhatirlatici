import os
import zipfile
from io import BytesIO
from datetime import datetime as dt

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, PasswordChangeForm
from django.contrib.auth.views import LoginView, LogoutView, PasswordChangeView
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import get_template, render_to_string
from django.urls import reverse_lazy
from django.utils.timezone import localdate, make_aware
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.csrf import csrf_protect

from xhtml2pdf import pisa

from .forms import (
    RegisterForm,
    LoginForm,
    CustomPasswordChangeForm,
    ProfileUpdateForm,
    AvatarUpdateForm,
    CustomUserCreationForm
)
from .models import FavoriteSalon

from appointments.models import Appointment, Salon
from appointments.forms import AppointmentForm
from appointments.utils import tahmini_saat_ozeti

# ... (diğer view'lar aynı şekilde kalacak)

class RegisterView(View):
    def get(self, request):
        form = UserCreationForm()
        return render(request, 'accounts/register.html', {'form': form})

    def post(self, request):
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, _('✅ Kayıt başarılı! Hoş geldiniz.'))
            return redirect('appointments:appointment_list')
        messages.error(request, _('❌ Kayıt başarısız. Lütfen formu kontrol edin.'))
        return render(request, 'accounts/register.html', {'form': form})


@login_required
def custom_login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, _('👋 Hoş geldiniz!'))
            return redirect('appointments:appointment_list')
        else:
            messages.error(request, _('❌ Giriş başarısız.'))
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})

from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from geopy.geocoders import Nominatim
from django.contrib.auth.decorators import login_required
import json

@csrf_exempt
@require_POST
def konum_al(request):
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Giriş yapılmamış."}, status=403)

    try:
        data = json.loads(request.body)
        latitude = data.get("latitude")
        longitude = data.get("longitude")

        if not latitude or not longitude:
            return JsonResponse({"error": "Geçerli enlem ve boylam girilmedi."}, status=400)

        geolocator = Nominatim(user_agent="kuaforapp")
        location = geolocator.reverse(f"{latitude}, {longitude}", language='tr')

        if location and 'address' in location.raw:
            city = location.raw['address'].get('city') or location.raw['address'].get('town') or location.raw['address'].get('village')
            if not city:
                return JsonResponse({"error": "Şehir bilgisi alınamadı."}, status=404)

            # Profil güncelle
            profile = request.user.profile
            profile.latitude = latitude
            profile.longitude = longitude
            profile.city = city
            profile.save()

            return JsonResponse({
                "success": True,
                "city": city,
                "latitude": latitude,
                "longitude": longitude
            })
        else:
            return JsonResponse({"error": "Konum verisi eksik."}, status=404)

    except json.JSONDecodeError:
        return JsonResponse({"error": "Geçersiz JSON verisi."}, status=400)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

@login_required
def manual_password_change(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, _('🔐 Şifreniz değiştirildi.'))
            return redirect('accounts:profile')
        else:
            messages.error(request, _('❌ Hata oluştu. Lütfen tekrar deneyin.'))
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'accounts/password_change.html', {'form': form})

@login_required
def home_view(request):
    önerilen_saat = tahmini_saat_ozeti(request.user)
    user_name = request.user.first_name or request.user.username
    return render(request, 'appointments/home.html', {
        'önerilen_saat': önerilen_saat,
        'user_name': user_name
    })


@login_required
def create_appointment(request):
    hata = None
    tahmin = tahmini_saat_ozeti(request.user)

    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            yeni = form.save(commit=False)
            çakışan = Appointment.objects.filter(
                salon_name=yeni.salon_name,
                appointment_date=yeni.appointment_date
            ).exists()

            if çakışan:
                hata = "❌ Bu saatte bu salonda zaten bir randevu var!"
            else:
                yeni.user = request.user
                yeni.save()
                return redirect('appointment_list')
    else:
        form = AppointmentForm(initial={'appointment_date': tahmin} if tahmin else None)

    return render(request, 'appointments/create_appointment.html', {
        'form': form,
        'hata': hata,
        'tahmini_saat': tahmin
    })


@login_required
def appointment_list(request):
    today = localdate()
    start = make_aware(dt.combine(today, dt.min.time()))
    end = make_aware(dt.combine(today, dt.max.time()))

    today_appointments = Appointment.objects.filter(
        appointment_date__range=(start, end),
        user=request.user
    )

    past_appointments = Appointment.objects.filter(
        appointment_date__lt=start,
        user=request.user
    )

    q = request.GET.get('q')
    if q:
        today_appointments = today_appointments.filter(
            Q(customer_name__icontains=q) | Q(phone_number__icontains=q)
        )
        past_appointments = past_appointments.filter(
            Q(customer_name__icontains=q) | Q(phone_number__icontains=q)
        )

    return render(request, 'appointments/appointment_list.html', {
        'appointments': today_appointments.order_by('appointment_date'),
        'past_appointments': past_appointments.order_by('-appointment_date'),
        'today': today
    })


@login_required
def randevu_pdf_xhtml2pdf(request, id):
    appointment = get_object_or_404(Appointment, id=id)
    return render_to_pdf('pdf_template_v2.html', {'appointment': appointment})


def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), result,
                            encoding='utf-8', link_callback=link_callback)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None


def link_callback(uri, rel):
    static_url = settings.STATIC_URL
    static_root = os.path.join(settings.BASE_DIR, 'static')
    path = os.path.join(static_root, uri.replace(static_url, "")) if uri.startswith(static_url) else os.path.join(static_root, uri)
    if not os.path.isfile(path):
        raise Exception('Statik dosya bulunamadı: %s' % path)
    return path


@login_required
def zip_randevu_pdfs(request):
    appointments = Appointment.objects.filter(user=request.user).order_by('-appointment_date')
    zip_buffer = BytesIO()

    with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
        for appointment in appointments:
            html = render_to_string('pdf_template_v2.html', {'appointment': appointment})
            pdf_buffer = BytesIO()
            pisa.CreatePDF(html, dest=pdf_buffer, encoding='utf-8', link_callback=link_callback)
            zip_file.writestr(f"randevu_{appointment.id}.pdf", pdf_buffer.getvalue())

    zip_buffer.seek(0)
    response = HttpResponse(zip_buffer, content_type='application/zip')
    response['Content-Disposition'] = 'attachment; filename="tum_randevular.zip"'
    return response


@login_required
def delete_appointment(request, id):
    appointment = get_object_or_404(Appointment, id=id, user=request.user)
    appointment.delete()
    return redirect('appointment_list')

from django.views.decorators.csrf import csrf_protect


def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, _('✅ Kayıt başarılı! Hoş geldiniz.'))
            Salon.objects.create(user=user, salon_name=f"{user.username} Salonu")  # 🔧 BURASI DÜZELTİLDİ
            return redirect('appointments:appointment_list')
        messages.error(request, _('❌ Kayıt başarısız. Lütfen formu kontrol edin.'))
    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})

class CustomLoginView(LoginView):
    template_name = 'accounts/login.html'

    def form_invalid(self, form):
        messages.error(self.request, _('❌ Kullanıcı adı veya parola hatalı.'))
        return super().form_invalid(form)


class CustomLogoutView(LogoutView):
    next_page = reverse_lazy('accounts:login')


class CustomPasswordChangeView(PasswordChangeView):
    template_name = 'accounts/password_change.html'
    success_url = reverse_lazy('accounts:profile')

    def form_valid(self, form):
        messages.success(self.request, _('🔐 Şifreniz başarıyla güncellendi.'))
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, _('❌ Şifre güncellenemedi. Lütfen tekrar deneyin.'))
        return super().form_invalid(form)

@login_required
def toggle_favorite(request, salon_id):
    salon = get_object_or_404(Salon, id=salon_id)
    fav, created = FavoriteSalon.objects.get_or_create(user=request.user, salon=salon)
    if not created:
        fav.delete()
        favorited = False
    else:
        favorited = True
    return JsonResponse({'favorited': favorited})


@csrf_protect
def toggle_theme(request):
    response = redirect(request.META.get('HTTP_REFERER', '/'))
    current = request.COOKIES.get('theme', 'light')
    new_theme = 'dark' if current == 'light' else 'light'
    response.set_cookie('theme', new_theme)
    return response

# accounts/views.py
from .forms import ProfileUpdateForm
from .models import Profile

@login_required
def profile_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)

    form = ProfileUpdateForm(request.POST or None, request.FILES or None, instance=profile)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Profil başarıyla güncellendi.")
            return redirect('accounts:profile')

    return render(request, 'accounts/profile.html', {
        'profile_form': form,
    })
