# appointments/management/commands/whatsapp_gorevi.py

from django.core.management.base import BaseCommand
from appointments.models import Appointment
from django.utils.timezone import now
from datetime import timedelta

class Command(BaseCommand):
    help = "1 saat sonra randevusu olanlara WhatsApp mesajı oluşturur"

    def handle(self, *args, **kwargs):
        print("✅ WhatsApp görevi tetiklendi")

        simdi = now()
        hedef_zaman = simdi + timedelta(hours=1)

        # Yaklaşık 1 saat sonra olan randevuları bul (±5 dakika toleranslı)
        alt_sinir = hedef_zaman - timedelta(minutes=5)
        ust_sinir = hedef_zaman + timedelta(minutes=5)

        randevular = Appointment.objects.filter(appointment_date__range=(alt_sinir, ust_sinir))

        if not randevular:
            print("⏳ Şu an için 1 saat sonra randevusu olan kimse yok.")
            return

        for r in randevular:
            mesaj = f"Merhaba {r.customer_name}, randevunuz {r.appointment_date.strftime('%d.%m.%Y %H:%M')}’dedir. Lütfen unutmayınız."
            link = f"https://wa.me/{r.phone_number}?text={mesaj.replace(' ', '%20')}"
            print(f"📤 {r.customer_name} → {link}")

        print("✅ WhatsApp mesajları hazırlandı.")
