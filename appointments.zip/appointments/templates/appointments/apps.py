import os
from django.apps import AppConfig
from django.conf import settings  # 💡 DEBUG kontrolü için eklendi

class AppointmentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appointments'

    def ready(self):
        # ✅ Geliştirme ortamında sadece bir kez, üretimde her zaman çalışır
        if os.environ.get('RUN_MAIN') == 'true' or not settings.DEBUG:
            from .scheduler import scheduler_start
            scheduler_start()
