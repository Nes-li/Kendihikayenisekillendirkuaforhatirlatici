from apscheduler.schedulers.background import BackgroundScheduler
from django.utils.timezone import now
from .models import Appointment
import datetime

def whatsapp_mesaj_gonder(randevu):
    print(f"[MESAJ] {randevu.customer_name} kişisine WhatsApp mesajı gönderilecek. ({randevu.appointment_date})")
    # Buraya WhatsApp entegrasyonu eklenecek (pywhatkit veya Twilio API)

def zamanli_kontrol():
    simdi = now()
    hedef_zaman = simdi + datetime.timedelta(hours=1)

    randevular = Appointment.objects.filter(
        appointment_date__hour=hedef_zaman.hour,
        appointment_date__date=hedef_zaman.date()
    )

    for r in randevular:
        whatsapp_mesaj_gonder(r)

def scheduler_start():
    scheduler = BackgroundScheduler()
    scheduler.add_job(zamanli_kontrol, 'interval', minutes=1)
    scheduler.start()

    import pywhatkit
    from django.utils.timezone import localtime
    
    def whatsapp_mesaj_gonder(randevu):
        zaman = localtime(randevu.appointment_date)
        saat = zaman.hour
        dakika = zaman.minute
    
        mesaj = f"📅 Merhaba {randevu.customer_name}, {zaman.strftime('%d.%m.%Y %H:%M')} tarihinde kuaför randevunuz var. Gelmeyi unutmayın! 💇‍♀️"
    
        try:
            pywhatkit.sendwhatmsg(f"+90{randevu.phone_number}", mesaj, saat, dakika - 1)
            print(f"✅ WhatsApp mesajı gönderildi: {randevu.phone_number}")
        except Exception as e:
            print("❌ Mesaj gönderilemedi:", e)

            import pywhatkit
            import time
            
            def whatsapp_mesaj_gonder_pywhatkit(randevu):
                if not randevu.whatsapp_izin:
                    return  # Rıza yoksa gönderme
            
                from django.utils.timezone import localtime
                zaman = localtime(randevu.appointment_date)
            
                mesaj = f"📅 Merhaba {randevu.customer_name}, {zaman.strftime('%d.%m.%Y %H:%M')} tarihinde kuaför randevunuz var. Gelmeyi unutmayın! 💇‍♀️"
            
                try:
                    # 1 dakika önce gönderelim
                    saat = zaman.hour
                    dakika = zaman.minute - 1
                    tel = f"+90{randevu.phone_number}"
            
                    pywhatkit.sendwhatmsg(
                        phone_no=tel,
                        message=mesaj,
                        time_hour=saat,
                        time_minute=dakika,
                        wait_time=10,  # kaç saniye önce açsın
                        tab_close=True
                    )
                    print(f"✅ pywhatkit ile gönderildi → {tel}")
                except Exception as e:
                    print("❌ pywhatkit hata:", e)
 
                    from twilio.rest import Client
                    from django.conf import settings
                    
                    def whatsapp_mesaj_gonder_twilio(randevu):
                        if not randevu.whatsapp_izin:
                            return
                    
                        client = Client(settings.TWILIO_SID, settings.TWILIO_TOKEN)
                    
                        mesaj = f"📅 Merhaba {randevu.customer_name}, {randevu.appointment_date.strftime('%d.%m.%Y %H:%M')} tarihinde kuaför randevunuz var. Gelmeyi unutmayın!"
                    
                        try:
                            mesaj = client.messages.create(
                                body=mesaj,
                                from_=settings.TWILIO_WHATSAPP_NUMBER,
                                to=f"whatsapp:+90{randevu.phone_number}"
                            )
                            print(f"✅ Twilio ile mesaj gönderildi: {randevu.phone_number}")
                        except Exception as e:
                            print("❌ Twilio hatası:", e)
 
                            from django.conf import settings

                            def zamanli_kontrol():
                                ...
                                for r in randevular:
                                    if settings.WHATSAPP_GONDERICI == 'twilio':
                                        whatsapp_mesaj_gonder_twilio(r)
                                    elif settings.WHATSAPP_GONDERICI == 'pywhatkit':
                                        whatsapp_mesaj_gonder_pywhatkit(r)
                                                        