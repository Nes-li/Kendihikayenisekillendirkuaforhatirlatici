from django.urls import path
from . import views
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from .views import konum_view
from .views import upload_post
from .views import profile_view
from django.contrib.auth.views import PasswordChangeView

admin.site.site_title = "Kuaför Yönetimi"
admin.site.site_header = "Kendi Hikâyeni Şekillendir"
admin.site.index_title = "Yönetim Paneli"

app_name = 'appointments'

urlpatterns = [
    path('upload/', views.upload_media, name='upload_media'),
    path('detail/<int:id>/', views.appointment_detail, name='appointment_detail'),
    path('salon-comments/', views.salon_comments, name='salon_comments'),
    path('update/<int:id>/', views.update_appointment, name='update_appointment'),
    path('reels/upload/', views.upload_post, name='reels_upload'),
    path('reels/<int:post_id>/like/', views.toggle_like, name='reel_like'),
    path('paylasimlar/', views.post_list, name='post_list'),
    path("sifre-degis/", PasswordChangeView.as_view(template_name="accounts/password_change.html"), name="password_change"),
    path('anlik/', views.anlik_list, name='anlik_list'),
    path('anlik/yukle/', views.upload_anlik, name='upload_anlik'),
    path('reels/<int:id>/', views.reel_detail, name='reel_detail'),
    path('profilim/', profile_view, name='profile'),
    path('konum/', konum_view, name='konum'),
    path('', views.appointment_list, name='appointment_list'),
    path('create/', views.create_appointment, name='create_appointment'),
    path('<int:id>/delete/', views.delete_appointment, name='delete_appointment'),
    path('<int:id>/pdf/', views.randevu_pdf, name='randevu_pdf'),
    path('<int:id>/pdf-weasy/', views.randevu_pdf_weasy, name='randevu_pdf_weasy'),
    path('whatsapp/<int:id>/', views.whatsapp_yonlendir, name='whatsapp_yonlendir'),
    path('panelim/', views.kullanici_paneli, name='kullanici_paneli'),
    path('saat-durumu/', views.saat_durumu_paneli, name='saat_durumu'),
    path('takvim/', views.takvim_view, name='takvim'),
    path('takvim/pdf/', views.takvim_pdf_view, name='takvim_pdf'),
    path('takvim-events/', views.calendar_events, name='calendar_events_alt'),
    path('grafik/', views.randevu_grafik_view, name='randevu_grafik'),
    path('grafik/pdf/', views.grafik_pdf_view, name='grafik_pdf'),
    path('test-ekle/', views.test_randevu_ekle, name='test_randevular'),
    path('media/upload/', views.upload_media_view, name='upload_media'),
    path('media/gallery/', views.media_gallery_view, name='media_gallery'),
    path('salonlar/', views.salon_list, name='salon_list'),
    path('salon/<int:id>/', views.salon_detail, name='salon_detail'),
    path('reels/', views.reels_list, name='reels_list'),
    path('reels/yukle/', views.upload_post, name='reels_upload'),
    path('reels/<int:id>/begen/', views.reel_begen, name='reel_begen'),
    path('reels/<int:id>/yorum/', views.reel_yorum, name='reel_yorum'),
    path('grafik-pdf/', views.grafik_pdf_view, name='grafik_pdf'),
    path('rapor/kategori/<int:salon_id>/', views.kategori_rapor_pdf, name='kategori_rapor_pdf'),
    path('raporlar/zip/<int:salon_id>/', views.zip_pdf_raporlar, name='zip_pdf_raporlar'),
    path('rapor/mail/<int:salon_id>/', views.pdf_mail_gonder, name='pdf_mail_gonder'),
    path('zip/', views.zip_randevu_pdfs, name='zip_randevular'),
    path('zip/all/', views.zip_randevular_view, name='zip_randevular_all'),
    path('reels/one-cikan/', views.featured_reels_view, name='featured_reels'),
    path('konum/', views.konum_al, name='konum_al'),
    path('grafik-pdf/', views.grafik_pdf_view, name='grafik_pdf'),
    path('secilen/pdfzip/', views.secilen_tarih_pdf_zip, name='secilen_pdf_zip'),
    path('secilen/grafik/', views.secilen_tarih_grafik_indir, name='secilen_grafik_indir'),
    path('secilen/ai/', views.secilen_tarih_ai_json, name='secilen_ai_json'),
    path('reels/upload/', upload_post, name='reels_upload'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
