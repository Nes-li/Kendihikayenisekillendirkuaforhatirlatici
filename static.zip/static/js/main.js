console.log("main.js yüklendi.");
